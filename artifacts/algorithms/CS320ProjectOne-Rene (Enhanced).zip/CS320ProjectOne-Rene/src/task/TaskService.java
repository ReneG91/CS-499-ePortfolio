package task;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TaskService {

    // HashMap stores each Task using its unique task ID as the key.
    private final Map<String, Task> tasks = new HashMap<>();

    // Adds a new task while preventing duplicate task IDs.
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }

        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists");
        }

        tasks.put(task.getTaskId(), task);
    }

    // Deletes a task by ID.
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID does not exist");
        }

        tasks.remove(taskId);
    }

    // Updates the name of an existing task.
    public void updateName(String taskId, String name) {
        Task task = getExistingTask(taskId);
        task.setName(name);
    }

    // Updates the description of an existing task.
    public void updateDescription(String taskId, String description) {
        Task task = getExistingTask(taskId);
        task.setDescription(description);
    }

    // Retrieves a task directly by its unique ID.
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    // Searches all tasks for names containing the provided keyword.
    // This uses a linear search through the stored tasks.
    public List<Task> searchTasksByName(String keyword) {
        if (keyword == null) {
            throw new IllegalArgumentException("Search keyword cannot be null");
        }

        List<Task> results = new ArrayList<>();
        String searchValue = keyword.toLowerCase();

        for (Task task : tasks.values()) {
            if (task.getName().toLowerCase().contains(searchValue)) {
                results.add(task);
            }
        }

        return results;
    }

    // Returns tasks sorted alphabetically by task name.
    public List<Task> getTasksSortedByName() {
        List<Task> sortedTasks = new ArrayList<>(tasks.values());

        sortedTasks.sort(
            Comparator.comparing(
                Task::getName,
                String.CASE_INSENSITIVE_ORDER
            )
        );

        return sortedTasks;
    }

    // Returns tasks sorted by their unique task ID.
    public List<Task> getTasksSortedById() {
        List<Task> sortedTasks = new ArrayList<>(tasks.values());

        sortedTasks.sort(
            Comparator.comparing(Task::getTaskId)
        );

        return sortedTasks;
    }

    // Helper method used by update operations.
    private Task getExistingTask(String taskId) {
        Task task = tasks.get(taskId);

        if (task == null) {
            throw new IllegalArgumentException("Task ID does not exist");
        }

        return task;
    }
}