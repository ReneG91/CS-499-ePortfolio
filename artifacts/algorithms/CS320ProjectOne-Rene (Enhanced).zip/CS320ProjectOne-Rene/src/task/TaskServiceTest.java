package task;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    @Test
    public void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("T1", "Test", "This is a test task");

        service.addTask(task);

        assertEquals(task, service.getTask("T1"));
    }

    @Test
    public void testDuplicateTaskId() {
        TaskService service = new TaskService();

        Task task1 = new Task("T1", "First", "First task");
        Task task2 = new Task("T1", "Second", "Second task");

        service.addTask(task1);

        assertThrows(
            IllegalArgumentException.class,
            () -> service.addTask(task2)
        );
    }

    @Test
    public void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("T1", "Test", "Test task");

        service.addTask(task);
        service.deleteTask("T1");

        assertNull(service.getTask("T1"));
    }

    @Test
    public void testDeleteMissingTask() {
        TaskService service = new TaskService();

        assertThrows(
            IllegalArgumentException.class,
            () -> service.deleteTask("T99")
        );
    }

    @Test
    public void testUpdateName() {
        TaskService service = new TaskService();
        Task task = new Task("T1", "Old Name", "Test task");

        service.addTask(task);
        service.updateName("T1", "New Name");

        assertEquals("New Name", service.getTask("T1").getName());
    }

    @Test
    public void testUpdateDescription() {
        TaskService service = new TaskService();
        Task task = new Task("T1", "Test", "Old description");

        service.addTask(task);
        service.updateDescription("T1", "New description");

        assertEquals(
            "New description",
            service.getTask("T1").getDescription()
        );
    }

    @Test
    public void testSearchTasksByName() {
        TaskService service = new TaskService();

        service.addTask(
            new Task("T1", "Finish Project", "Complete CS 499 project")
        );

        service.addTask(
            new Task("T2", "Study Java", "Review Java concepts")
        );

        service.addTask(
            new Task("T3", "Project Review", "Review project files")
        );

        List<Task> results = service.searchTasksByName("project");

        assertEquals(2, results.size());
    }

    @Test
    public void testSearchIsCaseInsensitive() {
        TaskService service = new TaskService();

        service.addTask(
            new Task("T1", "Study Java", "Review Java")
        );

        List<Task> results = service.searchTasksByName("JAVA");

        assertEquals(1, results.size());
        assertEquals("T1", results.get(0).getTaskId());
    }

    @Test
    public void testSortTasksByName() {
        TaskService service = new TaskService();

        service.addTask(new Task("T3", "Study", "Study Java"));
        service.addTask(new Task("T1", "Assignment", "Complete assignment"));
        service.addTask(new Task("T2", "Project", "Complete project"));

        List<Task> sortedTasks = service.getTasksSortedByName();

        assertEquals("Assignment", sortedTasks.get(0).getName());
        assertEquals("Project", sortedTasks.get(1).getName());
        assertEquals("Study", sortedTasks.get(2).getName());
    }

    @Test
    public void testSortTasksById() {
        TaskService service = new TaskService();

        service.addTask(new Task("T3", "Third", "Third task"));
        service.addTask(new Task("T1", "First", "First task"));
        service.addTask(new Task("T2", "Second", "Second task"));

        List<Task> sortedTasks = service.getTasksSortedById();

        assertEquals("T1", sortedTasks.get(0).getTaskId());
        assertEquals("T2", sortedTasks.get(1).getTaskId());
        assertEquals("T3", sortedTasks.get(2).getTaskId());
    }
}