package appointment;

import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {
    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appt = new Appointment("A2", futureDate, "Meeting");
        service.addAppointment(appt);
        assertEquals(appt, service.getAppointment("A2"));
    }
}
