package contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "Jane", "Smith", "0987654321", "456 Park Ave");
        service.addContact(contact);
        assertEquals(contact, service.getContact("123"));
    }
}
