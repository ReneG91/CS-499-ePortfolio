package task;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId()))
            throw new IllegalArgumentException("Task ID already exists");
        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        tasks.remove(taskId);
    }

    public void updateName(String taskId, String name) {
        tasks.get(taskId).setName(name);
    }

    public void updateDescription(String taskId, String description) {
        tasks.get(taskId).setDescription(description);
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
