package task;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
    @Test
    public void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("T1", "Test", "This is a test task");
        service.addTask(task);
        assertEquals(task, service.getTask("T1"));
    }
}
