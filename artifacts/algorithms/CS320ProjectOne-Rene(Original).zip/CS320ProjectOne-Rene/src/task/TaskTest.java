package task;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {
    @Test
    public void testTaskCreation() {
        Task task = new Task("T123", "Code", "Write unit tests");
        assertEquals("T123", task.getTaskId());
        assertEquals("Code", task.getName());
    }
}
