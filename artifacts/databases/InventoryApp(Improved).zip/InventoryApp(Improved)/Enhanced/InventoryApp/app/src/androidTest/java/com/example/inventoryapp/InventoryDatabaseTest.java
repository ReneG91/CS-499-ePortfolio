package com.example.inventoryapp;

import static org.junit.Assert.*;

import android.content.Context;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.ArrayList;

/** Run on an Android emulator/device; uses a separate test database context. */
@RunWith(AndroidJUnit4.class)
public class InventoryDatabaseTest {
    @Test
    public void searchAndLowStockFilterUseSQLite() {
        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        DBHelper db = new DBHelper(context);
        String unique = "CS499_" + System.nanoTime();
        long a = db.addItem(unique + " Apple", 2, 1.50);
        long b = db.addItem(unique + " Banana", 10, 2.00);
        try {
            assertTrue(a > 0);
            assertTrue(b > 0);
            ArrayList<InventoryItem> found = db.getFilteredItems(unique, false, 5);
            assertEquals(2, found.size());
            ArrayList<InventoryItem> low = db.getFilteredItems(unique, true, 5);
            assertEquals(1, low.size());
            assertEquals(a, low.get(0).getId());
            assertEquals(0, db.getFilteredItems(unique + " missing", false, 5).size());
        } finally {
            if (a > 0) db.deleteItem(a);
            if (b > 0) db.deleteItem(b);
            db.close();
        }
    }

    @Test
    public void invalidValuesAreRejected() {
        assertFalse(DBHelper.isValidItem("  ", 0, 0));
        assertFalse(DBHelper.isValidItem("Valid", -1, 0));
        assertFalse(DBHelper.isValidItem("Valid", 1, Double.NaN));
        assertFalse(DBHelper.isValidItem("Valid", 1, Double.POSITIVE_INFINITY));
        assertTrue(DBHelper.isValidItem("Valid", 0, 0));
    }
}
