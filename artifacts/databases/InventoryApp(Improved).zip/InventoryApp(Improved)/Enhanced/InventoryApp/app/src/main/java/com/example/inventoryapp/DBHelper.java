package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

/**
 * Central database helper for the app.
 * Uses SQLiteOpenHelper to manage database creation and version upgrades.
 */
public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory_app.db";
    private static final int DB_VERSION = 2;

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Items table
    private static final String TABLE_ITEMS = "items";
    private static final String COL_ITEM_ID = "id";
    private static final String COL_ITEM_NAME = "name";
    private static final String COL_ITEM_QTY = "quantity";
    private static final String COL_ITEM_PRICE = "price";

    public DBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                        COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USERNAME + " TEXT NOT NULL UNIQUE, " +
                        COL_PASSWORD + " TEXT NOT NULL" +
                        ");"
        );

        db.execSQL(
                "CREATE TABLE IF NOT EXISTS " + TABLE_ITEMS + " (" +
                        COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_ITEM_NAME + " TEXT NOT NULL, " +
                        COL_ITEM_QTY + " INTEGER NOT NULL DEFAULT 0, " +
                        COL_ITEM_PRICE + " REAL NOT NULL DEFAULT 0.0" +
                        ");"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    private void ensureSchema() {
        SQLiteDatabase db = getWritableDatabase();
        onCreate(db);
    }

    // ---------------------------
    // User / Login Methods
    // ---------------------------

    /**
     * Checks whether a username already exists in the database.
     */
    public boolean userExists(String username) {
        ensureSchema();

        if (username == null) return false;
        String u = username.trim();
        if (u.isEmpty()) return false;

        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;

        try {
            c = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID},
                    COL_USERNAME + "=?",
                    new String[]{u},
                    null,
                    null,
                    null
            );
            return c != null && c.moveToFirst();
        } finally {
            if (c != null) c.close();
        }
    }

    /**
     * Creates a new user if the username does not already exist.
     * Returns true when inserted successfully.
     */
    public boolean createUser(String username, String password) {
        ensureSchema();

        if (username == null || password == null) return false;

        String u = username.trim();
        String p = password.trim();
        if (u.isEmpty() || p.isEmpty()) return false;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USERNAME, u);
        cv.put(COL_PASSWORD, p);

        long result = db.insert(TABLE_USERS, null, cv);
        return result != -1;
    }

    /**
     * Validates a user's credentials.
     * Returns true if a row exists matching username + password.
     */
    public boolean validateLogin(String username, String password) {
        ensureSchema();

        if (username == null || password == null) return false;

        String u = username.trim();
        String p = password.trim();
        if (u.isEmpty() || p.isEmpty()) return false;

        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;

        try {
            c = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID},
                    COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                    new String[]{u, p},
                    null,
                    null,
                    null
            );
            return c != null && c.moveToFirst();
        } finally {
            if (c != null) c.close();
        }
    }

    // ---------------------------
    // Inventory Item Methods
    // ---------------------------

    public long addItem(InventoryItem item) {
        ensureSchema();

        if (item == null || !isValidItem(item.getName(), item.getQuantity(), item.getPrice())) {
            return -1;
        }

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_NAME, item.getName().trim());
        cv.put(COL_ITEM_QTY, item.getQuantity());
        cv.put(COL_ITEM_PRICE, item.getPrice());

        return db.insert(TABLE_ITEMS, null, cv);
    }

    public long addItem(String name, int quantity, double price) {
        if (!isValidItem(name, quantity, price)) return -1;
        return addItem(new InventoryItem(0L, name.trim(), quantity, price));
    }

    public ArrayList<InventoryItem> getAllItems() {
        ensureSchema();

        ArrayList<InventoryItem> results = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;

        try {
            c = db.query(
                    TABLE_ITEMS,
                    new String[]{COL_ITEM_ID, COL_ITEM_NAME, COL_ITEM_QTY, COL_ITEM_PRICE},
                    null,
                    null,
                    null,
                    null,
                    COL_ITEM_ID + " DESC"
            );

            if (c != null) {
                while (c.moveToNext()) {
                    long id = c.getLong(c.getColumnIndexOrThrow(COL_ITEM_ID));
                    String name = c.getString(c.getColumnIndexOrThrow(COL_ITEM_NAME));
                    int qty = c.getInt(c.getColumnIndexOrThrow(COL_ITEM_QTY));
                    double price = c.getDouble(c.getColumnIndexOrThrow(COL_ITEM_PRICE));

                    results.add(new InventoryItem(id, name, qty, price));
                }
            }
        } finally {
            if (c != null) c.close();
        }

        return results;
    }

    /**
     * Searches inventory in SQLite rather than filtering a cached UI list.
     * The bound query parameter prevents user text from becoming SQL code.
     * instr() treats %, _ and other search characters literally.
     * Low stock includes zero through the supplied threshold.
     */
    public ArrayList<InventoryItem> getFilteredItems(String nameQuery,
                                                     boolean lowStockOnly,
                                                     int lowStockThreshold) {
        if (lowStockThreshold < 0) {
            throw new IllegalArgumentException("Threshold must be nonnegative");
        }
        ArrayList<InventoryItem> results = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String search = nameQuery == null ? "" : nameQuery.trim();
        String selection = "instr(lower(" + COL_ITEM_NAME + "), lower(?)) > 0";
        String[] args;
        if (lowStockOnly) {
            selection += " AND " + COL_ITEM_QTY + " <= ?";
            args = new String[]{search, String.valueOf(lowStockThreshold)};
        } else {
            args = new String[]{search};
        }
        try (Cursor c = db.query(TABLE_ITEMS,
                new String[]{COL_ITEM_ID, COL_ITEM_NAME, COL_ITEM_QTY, COL_ITEM_PRICE},
                selection, args, null, null,
                COL_ITEM_NAME + " COLLATE NOCASE ASC, " + COL_ITEM_ID + " ASC")) {
            while (c.moveToNext()) {
                results.add(new InventoryItem(
                        c.getLong(c.getColumnIndexOrThrow(COL_ITEM_ID)),
                        c.getString(c.getColumnIndexOrThrow(COL_ITEM_NAME)),
                        c.getInt(c.getColumnIndexOrThrow(COL_ITEM_QTY)),
                        c.getDouble(c.getColumnIndexOrThrow(COL_ITEM_PRICE))));
            }
        }
        return results;
    }

    /** Rejects invalid inventory values before a database write. */
    public static boolean isValidItem(String name, int quantity, double price) {
        return name != null && !name.trim().isEmpty() && name.trim().length() <= 100
                && quantity >= 0 && price >= 0
                && !Double.isNaN(price) && !Double.isInfinite(price);
    }

    public boolean updateQuantity(long itemId, int newQty) {
        ensureSchema();

        if (newQty < 0) return false;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_QTY, newQty);

        int rows = db.update(TABLE_ITEMS, cv, COL_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
        return rows > 0;
    }

    public boolean updatePrice(long itemId, double newPrice) {
        ensureSchema();

        if (newPrice < 0 || Double.isNaN(newPrice) || Double.isInfinite(newPrice)) return false;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_PRICE, newPrice);

        int rows = db.update(TABLE_ITEMS, cv, COL_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
        return rows > 0;
    }

    public boolean updateName(long itemId, String newName) {
        ensureSchema();

        if (newName == null) return false;
        String n = newName.trim();
        if (n.isEmpty() || n.length() > 100) return false;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_NAME, n);

        int rows = db.update(TABLE_ITEMS, cv, COL_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
        return rows > 0;
    }

    public boolean deleteItem(long itemId) {
        ensureSchema();

        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(TABLE_ITEMS, COL_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
        return rows > 0;
    }
}
