package com.example.inventoryapp;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Typeface;
import android.text.InputType;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

/**
 * RecyclerView adapter for inventory rows.
 * Keeps row behaviors close to the UI layer and delegates persistence to DBHelper.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.VH> {

    private final Context context;
    private final DBHelper dbHelper;
    private final Runnable onInventoryChanged;
    private final NumberFormat currency = NumberFormat.getCurrencyInstance(Locale.US);

    // Adapter owns the current list being displayed; DB remains authoritative.
    private ArrayList<InventoryItem> items;

    public InventoryAdapter(Context context, ArrayList<InventoryItem> items,
                            DBHelper dbHelper, Runnable onInventoryChanged) {
        this.context = context;
        this.items = items;
        this.dbHelper = dbHelper;
        this.onInventoryChanged = onInventoryChanged;
    }

    /**
     * Replaces the adapter list and refreshes UI.
     * Central method prevents partial updates that can desync UI from DB.
     */
    public void setItems(ArrayList<InventoryItem> newItems) {
        this.items = newItems;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_inventory_item, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        InventoryItem item = items.get(position);

        // Bind model values to UI widgets.
        h.txtName.setText(item.getName());
        h.txtQty.setText(String.valueOf(item.getQuantity()));
        h.txtPrice.setText(currency.format(item.getPrice()));

        // Quantity decrement (clamped at 0 to avoid negative inventory).
        h.btnMinus.setOnClickListener(v -> {
            int updated = Math.max(0, item.getQuantity() - 1);
            if (dbHelper.updateQuantity(item.getId(), updated)) {
                onInventoryChanged.run();
            }
        });

        // Quantity increment.
        h.btnPlus.setOnClickListener(v -> {
            int updated = item.getQuantity() + 1;
            if (dbHelper.updateQuantity(item.getId(), updated)) {
                onInventoryChanged.run();
            }
        });

        // Delete removes from DB first, then removes from UI list.
        h.btnDelete.setOnClickListener(v -> {
            if (dbHelper.deleteItem(item.getId())) {
                onInventoryChanged.run();
            }
        });

        // Price editing is done via a dialog to keep the row layout minimal.
        h.txtPrice.setOnClickListener(v -> showEditPriceDialog(item, h.getAdapterPosition()));

        // Visual emphasis for destructive action.
        h.btnDelete.setColorFilter(ContextCompat.getColor(context, android.R.color.holo_red_dark));
    }

    /**
     * Prompts the user to edit the price and persists changes if valid.
     */
    private void showEditPriceDialog(InventoryItem item, int adapterPos) {
        final android.widget.EditText input = new android.widget.EditText(context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setHint("0.00");
        input.setText(String.valueOf(item.getPrice()));

        new AlertDialog.Builder(context)
                .setTitle("Edit Price")
                .setView(input)
                .setPositiveButton("Save", (d, which) -> {
                    String raw = input.getText() == null ? "" : input.getText().toString().trim();
                    if (TextUtils.isEmpty(raw)) return;

                    // Defensive parse protects against unexpected input edge cases.
                    double updatedPrice;
                    try {
                        updatedPrice = Double.parseDouble(raw);
                    } catch (NumberFormatException ex) {
                        return;
                    }

                    if (updatedPrice < 0 || !Double.isFinite(updatedPrice)) return;

                    if (dbHelper.updatePrice(item.getId(), updatedPrice)) {
                        onInventoryChanged.run();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public int getItemCount() {
        return items == null ? 0 : items.size();
    }

    /**
     * ViewHolder caches view references for performance.
     * Avoids repeated lookups during scrolling.
     */
    static class VH extends RecyclerView.ViewHolder {
        TextView txtName, txtQty, txtPrice;
        ImageButton btnMinus, btnPlus, btnDelete;

        VH(@NonNull View itemView) {
            super(itemView);

            txtName = itemView.findViewById(R.id.txtItemName);
            txtQty = itemView.findViewById(R.id.txtQty);
            txtPrice = itemView.findViewById(R.id.txtPrice);

            btnMinus = itemView.findViewById(R.id.btnMinus);
            btnPlus = itemView.findViewById(R.id.btnPlus);
            btnDelete = itemView.findViewById(R.id.btnDelete);

            // Simple emphasis to improve scanability in a list.
            txtName.setTypeface(txtName.getTypeface(), Typeface.BOLD);
        }
    }
}
