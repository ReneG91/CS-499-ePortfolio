package com.example.inventoryapp;

/**
 * Simple model object representing a single inventory row.
 * Keeps UI logic separate from the data representation.
 */
public class InventoryItem {

    private long id;
    private String name;
    private int quantity;
    private double price;

    public InventoryItem(long id, String name, int quantity, double price) {
        this.id = id;
        this.name = (name == null) ? "" : name.trim();
        this.quantity = Math.max(0, quantity);
        this.price = Math.max(0.0, price);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = (name == null) ? "" : name.trim();
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = Math.max(0, quantity);
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = Math.max(0.0, price);
    }
}
