package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Entry point (launcher) for the app.
 * Handles login and first-time account creation against the local SQLite database.
 */
public class MainActivity extends AppCompatActivity {

    private DBHelper dbHelper;

    private EditText edtUsername;
    private EditText edtPassword;
    private TextView txtStatus;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);

        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);
        txtStatus = findViewById(R.id.txtStatus);

        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreateAccount = findViewById(R.id.btnCreateAccount);

        btnLogin.setOnClickListener(v -> attemptLogin());
        btnCreateAccount.setOnClickListener(v -> attemptCreateAccount());
    }

    private void attemptLogin() {
        String username = safeTrim(edtUsername.getText() == null ? null : edtUsername.getText().toString());
        String password = safeTrim(edtPassword.getText() == null ? null : edtPassword.getText().toString());

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            txtStatus.setText("Enter a username and password.");
            return;
        }

        boolean ok = dbHelper.validateLogin(username, password);
        if (!ok) {
            txtStatus.setText("Login failed. Check your credentials.");
            return;
        }

        txtStatus.setText("Login successful.");
        startActivity(new Intent(MainActivity.this, InventoryActivity.class));
    }

    private void attemptCreateAccount() {
        String username = safeTrim(edtUsername.getText() == null ? null : edtUsername.getText().toString());
        String password = safeTrim(edtPassword.getText() == null ? null : edtPassword.getText().toString());

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            txtStatus.setText("Enter a username and password.");
            return;
        }

        if (dbHelper.userExists(username)) {
            txtStatus.setText("That username already exists.");
            return;
        }

        boolean created = dbHelper.createUser(username, password);
        if (created) {
            txtStatus.setText("Account created. You can log in now.");
        } else {
            txtStatus.setText("Could not create account. Try again.");
        }
    }

    private String safeTrim(String s) {
        return s == null ? "" : s.trim();
    }
}
