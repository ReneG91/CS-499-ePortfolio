package com.example.inventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * SMS settings screen.
 * Responsible for checking and requesting SEND_SMS runtime permission.
 * UI updates based on user's decision to enable/deny SMS capability.
 */
public class SmsSettingsActivity extends AppCompatActivity {

    private TextView txtSmsStatus;

    // Activity Result API is recommended over deprecated onRequestPermissionsResult patterns.
    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                updatePermissionUI(isGranted);
            });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inflate the SMS settings UI defined in XML.
        setContentView(R.layout.activity_sms_settings);

        txtSmsStatus = findViewById(R.id.txtSmsStatus);
        Button btnRequest = findViewById(R.id.btnRequestSmsPermission);

        // Initial state reflects current permission status.
        updatePermissionUI(hasSmsPermission());

        // Requests permission only when user explicitly interacts (best practice).
        btnRequest.setOnClickListener(v -> requestSmsPermission());
    }

    /**
     * Returns true when SEND_SMS is granted.
     * Checking permission is required before attempting any SMS operation.
     */
    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Requests SEND_SMS permission through the system prompt.
     * The result is delivered to smsPermissionLauncher callback.
     */
    private void requestSmsPermission() {
        if (hasSmsPermission()) {
            updatePermissionUI(true);
            return;
        }
        smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }

    /**
     * Central UI method to keep the visual state consistent.
     */
    private void updatePermissionUI(boolean granted) {
        if (granted) {
            txtSmsStatus.setText("SMS permission is enabled. Alerts can be sent when needed.");
        } else {
            txtSmsStatus.setText("SMS permission is disabled. The app will run, but no SMS alerts will be sent.");
        }
    }
}
