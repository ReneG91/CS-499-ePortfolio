package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

/**
 * Central database helper for the app.
 * Uses SQLiteOpenHelper to manage database creation and version upgrades.
 */
public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory_app.db";
    private static final int DB_VERSION = 2;

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Items table
    private static final String TABLE_ITEMS = "items";
    private static final String COL_ITEM_ID = "id";
    private static final String COL_ITEM_NAME = "name";
    private static final String COL_ITEM_QTY = "quantity";
    private static final String COL_ITEM_PRICE = "price";

    public DBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                        COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USERNAME + " TEXT NOT NULL UNIQUE, " +
                        COL_PASSWORD + " TEXT NOT NULL" +
                        ");"
        );

        db.execSQL(
                "CREATE TABLE IF NOT EXISTS " + TABLE_ITEMS + " (" +
                        COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_ITEM_NAME + " TEXT NOT NULL, " +
                        COL_ITEM_QTY + " INTEGER NOT NULL DEFAULT 0, " +
                        COL_ITEM_PRICE + " REAL NOT NULL DEFAULT 0.0" +
                        ");"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    private void ensureSchema() {
        SQLiteDatabase db = getWritableDatabase();
        onCreate(db);
    }

    // ---------------------------
    // User / Login Methods
    // ---------------------------

    /**
     * Checks whether a username already exists in the database.
     */
    public boolean userExists(String username) {
        ensureSchema();

        if (username == null) return false;
        String u = username.trim();
        if (u.isEmpty()) return false;

        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;

        try {
            c = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID},
                    COL_USERNAME + "=?",
                    new String[]{u},
                    null,
                    null,
                    null
            );
            return c != null && c.moveToFirst();
        } finally {
            if (c != null) c.close();
        }
    }

    /**
     * Creates a new user if the username does not already exist.
     * Returns true when inserted successfully.
     */
    public boolean createUser(String username, String password) {
        ensureSchema();

        if (username == null || password == null) return false;

        String u = username.trim();
        String p = password.trim();
        if (u.isEmpty() || p.isEmpty()) return false;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USERNAME, u);
        cv.put(COL_PASSWORD, p);

        long result = db.insert(TABLE_USERS, null, cv);
        return result != -1;
    }

    /**
     * Validates a user's credentials.
     * Returns true if a row exists matching username + password.
     */
    public boolean validateLogin(String username, String password) {
        ensureSchema();

        if (username == null || password == null) return false;

        String u = username.trim();
        String p = password.trim();
        if (u.isEmpty() || p.isEmpty()) return false;

        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;

        try {
            c = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID},
                    COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                    new String[]{u, p},
                    null,
                    null,
                    null
            );
            return c != null && c.moveToFirst();
        } finally {
            if (c != null) c.close();
        }
    }

    // ---------------------------
    // Inventory Item Methods
    // ---------------------------

    public long addItem(InventoryItem item) {
        ensureSchema();

        if (item == null) return -1;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_NAME, item.getName());
        cv.put(COL_ITEM_QTY, item.getQuantity());
        cv.put(COL_ITEM_PRICE, item.getPrice());

        return db.insert(TABLE_ITEMS, null, cv);
    }

    public long addItem(String name, int quantity, double price) {
        ensureSchema();

        InventoryItem item = new InventoryItem(0L, name, quantity, price);
        return addItem(item);
    }

    public ArrayList<InventoryItem> getAllItems() {
        ensureSchema();

        ArrayList<InventoryItem> results = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;

        try {
            c = db.query(
                    TABLE_ITEMS,
                    new String[]{COL_ITEM_ID, COL_ITEM_NAME, COL_ITEM_QTY, COL_ITEM_PRICE},
                    null,
                    null,
                    null,
                    null,
                    COL_ITEM_ID + " DESC"
            );

            if (c != null) {
                while (c.moveToNext()) {
                    long id = c.getLong(c.getColumnIndexOrThrow(COL_ITEM_ID));
                    String name = c.getString(c.getColumnIndexOrThrow(COL_ITEM_NAME));
                    int qty = c.getInt(c.getColumnIndexOrThrow(COL_ITEM_QTY));
                    double price = c.getDouble(c.getColumnIndexOrThrow(COL_ITEM_PRICE));

                    results.add(new InventoryItem(id, name, qty, price));
                }
            }
        } finally {
            if (c != null) c.close();
        }

        return results;
    }

    public boolean updateQuantity(long itemId, int newQty) {
        ensureSchema();

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_QTY, Math.max(0, newQty));

        int rows = db.update(TABLE_ITEMS, cv, COL_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
        return rows > 0;
    }

    public boolean updatePrice(long itemId, double newPrice) {
        ensureSchema();

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_PRICE, Math.max(0.0, newPrice));

        int rows = db.update(TABLE_ITEMS, cv, COL_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
        return rows > 0;
    }

    public boolean updateName(long itemId, String newName) {
        ensureSchema();

        if (newName == null) return false;
        String n = newName.trim();
        if (n.isEmpty()) return false;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_NAME, n);

        int rows = db.update(TABLE_ITEMS, cv, COL_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
        return rows > 0;
    }

    public boolean deleteItem(long itemId) {
        ensureSchema();

        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(TABLE_ITEMS, COL_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
        return rows > 0;
    }
}
