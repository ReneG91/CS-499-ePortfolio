package com.example.inventoryapp;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * Inventory screen showing a grid/list of items.
 * Uses RecyclerView + Adapter as the presentation layer.
 * DBHelper acts as the persistence layer (SQLite).
 */
public class InventoryActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private InventoryAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inflate the inventory UI defined in XML.
        setContentView(R.layout.activity_inventory);

        dbHelper = new DBHelper(this);

        // RecyclerView is used for performance and flexibility with row layouts.
        RecyclerView recycler = findViewById(R.id.recyclerInventory);
        recycler.setLayoutManager(new LinearLayoutManager(this));

        // Adapter owns the list shown on-screen; DB remains the source of truth.
        adapter = new InventoryAdapter(this, dbHelper.getAllItems(), dbHelper);
        recycler.setAdapter(adapter);

        // Add Item triggers controlled item creation.
        Button btnAdd = findViewById(R.id.btnAddItem);
        btnAdd.setOnClickListener(v -> showAddItemDialog());

        // SMS Settings routes to the permission/settings screen.
        Button btnSmsSettings = findViewById(R.id.btnSmsSettings);
        btnSmsSettings.setOnClickListener(v ->
                startActivity(new Intent(InventoryActivity.this, SmsSettingsActivity.class))
        );
    }

    /**
     * Dialog-based item creation keeps the UI simple and avoids navigating away.
     */
    private void showAddItemDialog() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setHint("Item name");

        new AlertDialog.Builder(this)
                .setTitle("Add Item")
                .setView(input)
                .setPositiveButton("Add", (dialog, which) -> {
                    String name = input.getText() == null ? "" : input.getText().toString().trim();

                    // Validate to keep database clean and prevent placeholder junk.
                    if (TextUtils.isEmpty(name)) return;

                    // Insert defaults; user can adjust quantity/price via row controls.
                    dbHelper.addItem(name, 0, 0.0);

                    // Refresh from DB to ensure UI matches persisted state.
                    refreshList();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Pulls the latest list from the database and updates the adapter.
     * Centralizing refresh logic reduces duplication and bugs.
     */
    private void refreshList() {
        ArrayList<InventoryItem> updated = dbHelper.getAllItems();
        adapter.setItems(updated);
    }
}
