package com.example.module6_sensorapp;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final String TAG = "SensorDemo";

    private SensorManager sensorManager;
    private Sensor accelerometer;

    private TextView textStatus;
    private TextView textValues;

    private MotionDetector motionDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textStatus = findViewById(R.id.textStatus);
        textValues = findViewById(R.id.textValues);

        motionDetector = new MotionDetector();

        sensorManager =
                (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        if (sensorManager == null) {
            textStatus.setText("Status: Sensor service unavailable");
            textValues.setText(
                    "Motion detection cannot run on this device."
            );
            return;
        }

        accelerometer =
                sensorManager.getDefaultSensor(
                        Sensor.TYPE_ACCELEROMETER
                );

        if (accelerometer == null) {
            textStatus.setText("Status: Accelerometer unavailable");
            textValues.setText(
                    "This device does not provide an accelerometer."
            );
        } else {
            textStatus.setText("Status: Accelerometer ready");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (sensorManager != null && accelerometer != null) {

            boolean registered =
                    sensorManager.registerListener(
                            this,
                            accelerometer,
                            SensorManager.SENSOR_DELAY_NORMAL
                    );

            if (registered) {
                textStatus.setText(
                        "Status: Listening for movement"
                );
            } else {
                textStatus.setText(
                        "Status: Unable to start sensor listener"
                );
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        if (event == null ||
                event.sensor == null ||
                event.values == null ||
                event.values.length < 3) {

            Log.w(TAG, "Invalid sensor event received.");
            return;
        }

        if (event.sensor.getType()
                != Sensor.TYPE_ACCELEROMETER) {
            return;
        }

        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        MotionDetector.MotionResult result =
                motionDetector.analyze(x, y, z);

        String output = String.format(
                Locale.US,
                "Accelerometer\n\n" +
                        "X: %.2f m/s²\n" +
                        "Y: %.2f m/s²\n" +
                        "Z: %.2f m/s²\n\n" +
                        "Acceleration Magnitude: %.2f m/s²\n" +
                        "Movement Amount: %.2f m/s²\n\n" +
                        "Motion State: %s",
                x,
                y,
                z,
                result.getMagnitude(),
                result.getMovementAmount(),
                result.getMotionState()
        );

        textValues.setText(output);

        Log.d(
                TAG,
                "X=" + x +
                        ", Y=" + y +
                        ", Z=" + z +
                        ", Magnitude=" + result.getMagnitude() +
                        ", Movement=" + result.getMovementAmount() +
                        ", State=" + result.getMotionState()
        );
    }

    @Override
    public void onAccuracyChanged(
            Sensor sensor,
            int accuracy
    ) {
        // Required by SensorEventListener.
    }
}