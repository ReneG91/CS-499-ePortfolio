package com.example.module6_sensorapp;

import android.hardware.SensorManager;

public class MotionDetector {

    private static final float STATIONARY_THRESHOLD = 0.5f;
    private static final float MOVEMENT_THRESHOLD = 3.0f;
    private static final float SHAKE_THRESHOLD = 8.0f;

    public MotionResult analyze(float x, float y, float z) {

        float magnitude = calculateMagnitude(x, y, z);

        float movementAmount =
                calculateMovementAmount(magnitude);

        String motionState =
                determineMotionState(movementAmount);

        return new MotionResult(
                magnitude,
                movementAmount,
                motionState
        );
    }

    private float calculateMagnitude(
            float x,
            float y,
            float z
    ) {

        return (float) Math.sqrt(
                (x * x) +
                        (y * y) +
                        (z * z)
        );
    }

    private float calculateMovementAmount(
            float magnitude
    ) {

        return Math.abs(
                magnitude -
                        SensorManager.GRAVITY_EARTH
        );
    }

    private String determineMotionState(
            float movementAmount
    ) {

        if (movementAmount < STATIONARY_THRESHOLD) {
            return "Stationary";
        }

        if (movementAmount < MOVEMENT_THRESHOLD) {
            return "Moving";
        }

        if (movementAmount < SHAKE_THRESHOLD) {
            return "Sudden Movement Detected";
        }

        return "Shaking";
    }

    public static class MotionResult {

        private final float magnitude;
        private final float movementAmount;
        private final String motionState;

        public MotionResult(
                float magnitude,
                float movementAmount,
                String motionState
        ) {
            this.magnitude = magnitude;
            this.movementAmount = movementAmount;
            this.motionState = motionState;
        }

        public float getMagnitude() {
            return magnitude;
        }

        public float getMovementAmount() {
            return movementAmount;
        }

        public String getMotionState() {
            return motionState;
        }
    }
}