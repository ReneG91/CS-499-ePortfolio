package com.example.module6_sensorapp;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final String TAG = "SensorDemo";

    private SensorManager sensorManager;
    private Sensor accelerometer;

    private TextView textStatus;
    private TextView textValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textStatus = findViewById(R.id.textStatus);
        textValues = findViewById(R.id.textValues);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        if (sensorManager == null) {
            textStatus.setText("Status: SensorManager not available");
            textValues.setText("No sensor service on this device");
            return;
        }

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        if (accelerometer == null) {
            textStatus.setText("Status: Accelerometer not found");
            textValues.setText("Try a different emulator image or a physical device");
        } else {
            textStatus.setText("Status: Accelerometer ready");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (sensorManager != null && accelerometer != null) {
            sensorManager.registerListener(
                    this,
                    accelerometer,
                    SensorManager.SENSOR_DELAY_NORMAL
            );
            textStatus.setText("Status: Listening to accelerometer");
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event == null || event.sensor == null) return;

        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            String output = String.format(
                    Locale.US,
                    "Accelerometer\nX: %.2f\nY: %.2f\nZ: %.2f",
                    x, y, z
            );

            textValues.setText(output);

            Log.d(TAG, "Accel x=" + x + " y=" + y + " z=" + z);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not needed for this assignment, but required by the interface
    }
}
